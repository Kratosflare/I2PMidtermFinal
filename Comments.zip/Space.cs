﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
// Code referenced from Professor Hadley's MazeGame tutorial

namespace I2PMidtermFinal
{
    class Space
    {
        //<summary>
        //<variable> Row <data type> int <description> variable called Row that can hold a number
        //<variable> Column <data type> int <description> variable called Column that can hold a number
        //<variable> Floor <data type> string[,] <description> creates a grid of strings called Floor
        //<\summary>
      readonly int Row;
      readonly int Column;
      readonly private string[,] Floor;

        //<summary>
        //The <c> Space<c> initializes the variables with the value floor.GetLength
        //<param name = "floor"> initializes <c>Space<c> method with the parameter being string[,]
        //<\summary>
        public Space(string[,] floor)
        {
            Floor = floor;
            Row = floor.GetLength(0);
            Column = floor.GetLength(1);
        }

        //<summary>
        //<c>Render<c> method updates the string Person's x and y position
        //<\summary>
        public void Render()
        {
            for (int y = 0; y < Row; y++)
            {
                for (int x = 0; x < Column; x++)
                {
                    string Person = Floor[y, x];
                    SetCursorPosition(x, y);
                    WriteLine(Person);
                }
            }
        }
        //<summary>
        //Returns the person' position at the returned floor coordinates
        //<param name= "int x"> Integer known as x
        //<param name = "int y"> Integer known as y
        //<\summary>
        public string GetPersonAt(int x, int y)
        {
            return Floor[y, x];
        }
        //<summary>
        //<c>IsPositionWalkable<c> method determines which areas on Floor[y,x] are player accessible
        
        //<\summary>
        public bool IsPositionWalkable(int x, int y)
        {
            // Check bounds
            //<summary>
            //If the x and y values are greater than or equal to the column and row value,
            //The player cannot access that position
            // the same goes for any value less than 0, such as negative numbers
            //<\summary>
            if (x < 0 || y < 0 || x >= Column || y >= Row)
            {
                return false;
            }

            //<par>
            //checks if walkable
            //<code>
            //return Floor[y, x] == " " || Floor[y, x] == "X" || Floor[y, x] == "" ||
            //   Floor[y, x] == "1" || Floor[y, x] == "2"
            //   || Floor[y, x] == "3" ||
            //   Floor[y, x] == "4" ||
            //   Floor[y, x] == "5"
            //   || Floor[y, x] == "6";
            //<\code>
            // returns any position on the floor grid with the specified requirements
            //<example>
            // if the player moves to wherever the grid shows "1", the player's position can go there, simulating movement
            //<\example>
            //<\para>
            return Floor[y, x] == " " || Floor[y, x] == "X" || Floor[y,x] == "" || 
                Floor[y, x] == "1" || Floor[y, x] == "2" 
                || Floor[y, x] == "3" ||
                Floor[y, x] == "4" || 
                Floor[y, x] == "5" 
                || Floor[y, x] == "6";
        }
    }
}
