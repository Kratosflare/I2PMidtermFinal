﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
// Code referenced from Professor Hadley's MazeGame tutorial
namespace I2PMidtermFinal
{
    
    class Player
    {
        //<summary>
        //<variable> X <data type> int <description> receives a value for X and sets as that value
        //<variable> Y <data type> int <description> receives a value for Y and sets as that value
        //<variable> PlayerMarker <data type> string <description> creates a usable string called PlayerMarker
        //<variable> PlayerColor <data type> ConsoleColor <description> creates a variable referencing ConsoleColor called PlayerColor
        //<\summary>
        public int X { get; set; }
        public int Y { get; set; }

        readonly private string PlayerMarker;

        readonly private ConsoleColor PlayerColor;

        //<summary>
        // The <c>Player<c> method
        //<param name = "InitialX"> grants the player's initial 'x' position when the game starts
        //<param name = "InitialY"> grants the player's initial 'y' position when the game starts
        //<code>
        // PlayerMarker = "0";
       // PlayerColor = ConsoleColor.Blue;
        //<\code>
        //Sets the PlayerMarker variable as the string "0" and sets the Playercolor variable as the color blue.
        //<\summary>
        public Player(int InitialX, int InitialY)
        {
            X = InitialX;
            Y = InitialY;
            PlayerMarker = "0";
            PlayerColor = ConsoleColor.Blue;
        }


        //<summary>
        // The<c>Draw<c> method assigns the ForegroundColor to the PlayerColor
        // <code>
        //SetCursorPosition(X, Y);
        //Write(PlayerMarker);
       // ResetColor();
       // <\code>
       //Sets the cursor position to and x,y position and writes the Playermarker there. 
        //Then resets the color to distinguish the player from the starting point.
        //<\summary>
        public void Draw()
        {
            ForegroundColor = PlayerColor;
            SetCursorPosition(X, Y);
            Write(PlayerMarker);
            ResetColor();
        }

    }
}
