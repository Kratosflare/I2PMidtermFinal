﻿using System;

namespace I2PMidtermFinal
{
    class Program
    {
        //<summary>
        //<c> Main<c> instantiates Doors as a "doors" variable and calls its <c>Start<c> method.
        static void Main()
        {
            Doors doors = new Doors();
            doors.Start();
        }
    }
}
