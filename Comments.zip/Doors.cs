﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
using System.Threading;
using System.IO;
// Code referenced from Professor Hadley's MazeGame tutorial
//<summary>
// This is the skeleton of how the game plays out
// The game starts with the<c>Intro<c> constructor called which which calls the <c>RunGameLoop<c> method after <code>Writeline(Voice1);<code>
//<c>RunGameLoop<c> runs, it calls <c>DrawingSpace<c> and <c>HandlePlayerInput<c> while the game is running
//When <c>DrawingSpace<c> is running, it clears the current screen and calls for the <c>Render<c> method from <variable>world<variable> and the <c>Draw<c> method from <variable>player0<variable>
//<\summary>

namespace I2PMidtermFinal
{
    class Doors
    {
        //<summary>
        //<variable> world<datatype>Space<description> variable representing the <c>Space<c> class
        //<variable> player0<datatype>Player<description> variable representing the <c>Player<c> class
        //<variable> Inventory<datatype>List<description> variable representing an instantiated <c>List<c> class
        //<variable> Answer<datatype>string<description> variable that holds strings under the name "Answer"
        //<variable> Input<datatype>string<description> variable that holds strings under the name "Input"
        //<variable> Voice1<datatype>string<description> variable that holds strings under the name "Voice1"
        //<\summary>
        private Space world;
        private Player player0;
        readonly List<string> Inventory = new List<string>();
        string Answer;
        string Input;
        //Access to an available data file
        readonly string Voice1 = @"C:\Users\mepow\OneDrive - Columbia College Chicago\Spring2020\I2PMidtermFinal\I2PMidtermFinal\Adam.txt";
        //<summary>
        //<c> Start<c> method holds <datatype> string[,] = "Hallway"
        //and instantiates new variables, 'player0' and 'world' with new parameters from the class they instantiate from
        //Then<c> Start<c> calls upon <c> Intro<c> and <c> Drawing Space<c> methods.
        //<\summary>
        public void Start()
        {
            string[,] Hallway = {
            {"|"," ", " ", " ", " ", "0"," ", " ", " ", "|", "", "", "", "", "", },
            {"|"," ", " ", " ", " ", " "," ", " ", " ", "|", "", "", "", "", "", },
            {"|"," ", " ", " ", " ", " "," ", " ", " ", "|" ,"", "", "", "", "",},
            {"|"," ", " ", " ", " ", " "," ", " ", " ", "|", "", "", "", "", "", },
            {"|"," ", " ", " ", " ", " "," ", " ", " ", "|", "", "", "", "", "",  },
            {"|","_", "_", "_ ", " ", " ","_", "_", "_","|", "", "", "", "", "", },
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "", "", "", "", "", },
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "", "_", "_", "_", "_"},
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "|", "", "", "", "", },
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "|", "", "", "", "1", },
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "|", "", "", "", "", },
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "|", "", "_", "_", "_", },
             {" "," ", " ", "|", " ", " ","|", " ", " ", " ", "|", "", "", "", "", },
             {" "," ", " ", "|", " ", " ","|", "_", "_", "_", "|", "", "", "", "2", },
             {"_","_", "_", "|", " ", " "," ", " ", " ", " ", "", "", "", "", "", },
             {"|"," ", " ", "|", " ", " "," ", " ", " ", " ", "", "", "_", "_", "_", },
             {"|"," ", " ", "|", " ", " "," ", " ", " ", " ", " ", "", "", "", "", },
             {"|","X", " ", " ", " ", " ","|", "_", "_", "_", "_", "", "", "", "3", },
             {"|"," ", " ", "|", " ", " ","|", "", " ", " ", "|", "", "", "", "", },
             {"|"," ", " ", "|", " ", " ","|", "", " ", " ", "|", "_", "_", "_", "_", },
             {"|","_", "_", "|", " ", " ","|", "", " ", " ", "", "", "", "", "", },
             {" "," ", " ", "|", " ", " ","|", "", " ", " ", "", "", "", "", "",},
             {"_","_", "_", "|", " ", " ","|", "_", "_", "_", "_", "_", "_", "_", "_", },
             {"|"," ", " ", " ", " ", " "," ", "", " ", " ", "", "", "", "", "", },
             {"|"," ", " ", " ", " ", " "," ", "", " ", " ", "", "", "", "", "6", },
             {"|","4", " ", "|", " ", " ","|", "_", "_", "_", "_", "_", "_", "_", "_", },
             {"|"," ", " ", "|", " ", " ","|", "", " ", " ", "", "", "", "", "", },
             {"|"," ", " ", "|", " ", " ","|", "", " ", " ", "", "", "", "", "", },
             {"|","_", "_", "|", "", "5 ","|", "", " ", " ", "", "", "", "", "", },

        };
            player0 = new Player(5, 0);
            world = new Space(Hallway);
            Intro();
            DrawingSpace();
        }
        //<summary>
        //<c>Intro<c> Displays the Title and introduces the player to the scenario
        //Controls and Objectives are established
        //Calls a data text file and calls <c>RunGameLoop<c> method
        //<\summary>
        void Intro()
        {
            Title = "Hunted";
            WriteLine("Before we start, I'd like to learn your name.");
            Input = ReadLine();
            WriteLine(Input + " Hm. I'll make sure I remember that. Now let's begin");
            WriteLine("You wake up in a hopital bed with bandages on your arms, legs and head. You decide to exit the room");
            ReadKey();
            ForegroundColor = ConsoleColor.Blue;
            WriteLine("Man, I wish I had my stuff instead of a stupid gown. That way I'll get a ride home as a normal person");
            ResetColor();
            ReadKey();
            WriteLine("You must search various rooms to find your belongings. You need your Clothes, your Keys, Watch and Phone. \nSimple enough");
            ReadKey();
            WriteLine("However, an eerie voice starts ringing in your ears");
            ForegroundColor = ConsoleColor.Red;
            WriteLine(File.ReadAllText(Voice1));
            ResetColor();
            ReadKey();
            RunGameLoop();
          
        }

        //<summary>
        // The<c>DrawingSpace<c> method clears the current screen and calls 
        //methods<c>Render<c> from the 'world' variable and <c> Draw <c> from the 'player0' variable
        //<\summary>
        void DrawingSpace()
        {
            Clear();
            world.Render();
            player0.Draw();
        }

        //<summary>
        // When <c> RunGameLoop<c> is running, it calls <c>DrawingSpace<c> and <c>HandlePlayerInput<c>
        //While the game is running, it updates each position change every 20 miliseconds<code>Thread.Sleep(20);<code>
        //it also updates every time the player gets to specific locations
        //<\summary>
        private void RunGameLoop()
        {
            while (true)
            {
                DrawingSpace();
                HandlePlayerInput();
                Thread.Sleep(20);

                string Content;

                string Voice2 = @"C:\Users\mepow\OneDrive - Columbia College Chicago\Spring2020\I2PMidtermFinal\I2PMidtermFinal\Voice2.txt";
                string Voice3 = @"C:\Users\mepow\OneDrive - Columbia College Chicago\Spring2020\I2PMidtermFinal\I2PMidtermFinal\Voice3.txt";
                string Voice4 = @"C:\Users\mepow\OneDrive - Columbia College Chicago\Spring2020\I2PMidtermFinal\I2PMidtermFinal\Voice4.txt";

                // gets the player's current position as a  variable
                string currentPlayerPos = world.GetPersonAt(player0.X, player0.Y);

                // If the player hits X its "if" statement happens and ends the game with break keyword
                if (currentPlayerPos == "X")
                {
                    if (Inventory.Contains("Clothes") && Inventory.Contains("Keys") && Inventory.Contains("Watch") && Inventory.Contains("Phone"))
                    {
                        Clear();
                        WriteLine("You were able to leave with everything you need!");
                        WriteLine("Press enter to exit");
                        ReadKey(true);
                        break;
                    }
                    
                }
                // If the player hits 1 its "if" statement happens and returns to the maze
                if (currentPlayerPos == "1")
                {
                    Clear();
           
                    if (File.Exists(Voice2))
                    {
                        Content = File.ReadAllText(Voice2);
                        ForegroundColor = ConsoleColor.Red;
                        WriteLine(Content);
                        ResetColor();
                        ReadKey();
                    }
                    WriteLine("Here's a hint. Some rooms have items that might tell you where your things are");
                    ReadKey();
                }
                // If the player hits 2 its "if" statement happens and returns to the maze
                if (currentPlayerPos == "2")
                {
                    Clear();
                    WriteLine("Look it's your keys! But it's not everything. ");
                    ReadKey();
                    ForegroundColor = ConsoleColor.Blue;
                    WriteLine("What's this? a number? 6?");
                    Inventory.Add("Keys");
                    ResetColor();
                    ReadKey();
                }
                // If the player hits 3 its "if" statement happens and returns to the maze
                if (currentPlayerPos == "3")
                {
                    Clear();
                    ForegroundColor = ConsoleColor.Blue;
                    WriteLine("Finally some clothes. Now I can get out of here in style!");
                    Inventory.Add("Clothes");
                    ResetColor();
                    ReadKey();
                    
                }
                // If the player hits 4 its "if" statement happens and returns to the maze
                if (currentPlayerPos == "4")
                {
                    Clear();
                    Inventory.Add("Room Key");
                    ForegroundColor = ConsoleColor.Blue;
                    WriteLine("Yes! I got my phone and I can call for help");
                    ReadKey();
                    ForegroundColor = ConsoleColor.Red;
                    WriteLine("Should you?");
                    ReadKey();
                    ForegroundColor = ConsoleColor.Blue;
                    WriteLine("What the?");
                    WriteLine("I should ignore it (answer y/n)");
                    ResetColor();
                    Answer = ReadLine();
                    Answer.ToLower();
                    
                    if (Answer == "n")
                    {
                        if (File.Exists(Voice3))
                        {
                            ForegroundColor = ConsoleColor.Red;
                            Content = File.ReadAllText(Voice3);
                            WriteLine(Content);
                            ResetColor();
                        }
                        ReadKey();
                    }
                    else if (Answer == "y")
                    {
                        Inventory.Add("Phone");
                        ReadKey();
                    }

                    
                }
                // If the player hits 5 its "if" statement happens and ends the game
                if (currentPlayerPos == "5")
                {
                   

                    if(Inventory.Contains("Room Key"))
                    {
                        Clear();
                        ForegroundColor = ConsoleColor.Blue;
                        WriteLine("Oh my God! What the hell is this?! ");
                        ResetColor();
                        ReadKey();
                        WriteLine("You see a dead body horribly mangled with its intestines outside the body.");
                        ReadKey();
                        WriteLine("but...");
                        ReadKey();
                        ForegroundColor = ConsoleColor.DarkBlue;
                        WriteLine("THE INTESTINES SPELL OUT SOMETHING!");
                        ResetColor();
                        ReadKey();
                        ForegroundColor = ConsoleColor.DarkRed;
                        WriteLine(Input);
                        ResetColor();
                        ReadKey();
                        WriteLine("You lean in closer to read more..... it says....");
                        if (File.Exists(Voice4))
                        {
                            ForegroundColor = ConsoleColor.DarkRed;
                            Content = File.ReadAllText(Voice4);
                            WriteLine(Content);
                        }
                        WriteLine("Shocked by the unusual imagery, you slip on some blood, losing balance and smash your head on the ground.");
                        ReadKey();
                        WriteLine("So your basically dead.");
                       ReadKey();
                        break;

                    }


                }
                // If the player hits 6 its "if" statement happens and returns to the maze
                if (currentPlayerPos == "6")
                {
                    Clear();
                    WriteLine("You find a sheet of paper with some writing on it");
                    ForegroundColor = ConsoleColor.Magenta;
                    ReadKey();
                    WriteLine("Don't forget, you are " + Input + " and no one else.");
                    ResetColor();
                    ReadKey();
                    WriteLine("Nice words coming from your other half to cherish.");
                    ForegroundColor = ConsoleColor.Blue;
                    ReadKey();
                    WriteLine("There's a number on the back. 3? what does that have to do with anything?");
                    ResetColor();
                  ReadKey();

                    if(Inventory.Contains("Keys"))
                    {
                        Inventory.Add("Watch");
                        WriteLine("Hey my watch! Come to think of it, How long was I here?");
                    }
                }


            }

        }
        //<summary>
        //<c>HandlePlayerInput<c> method configures the arrow keys when pressed for up, down, left and right
        //<\summary>
        private void HandlePlayerInput()
        {
            ConsoleKeyInfo keyInfo = ReadKey(true);
            ConsoleKey key = keyInfo.Key;
            switch (key)
            {
                case ConsoleKey.UpArrow:
                    if (world.IsPositionWalkable(player0.X, player0.Y - 1))
                    {
                        player0.Y -= 1;
                    }

                    break;

                case ConsoleKey.DownArrow:
                    if (world.IsPositionWalkable(player0.X, player0.Y + 1))
                    {
                        player0.Y += 1;
                    }

                    break;

                case ConsoleKey.LeftArrow:
                    if (world.IsPositionWalkable(player0.X - 1, player0.Y))
                    {
                        player0.X -= 1;
                    }

                    break;
                case ConsoleKey.RightArrow:
                    if (world.IsPositionWalkable(player0.X + 1, player0.Y))
                    {
                        player0.X += 1;
                    }

                    break;
                default:
                    break;
            }
        }
    }
}

